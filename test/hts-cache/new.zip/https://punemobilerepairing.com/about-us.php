<!doctype html><html lang="en"><head>	<meta charset="utf-8">	<meta http-equiv="X-UA-Compatible" content="IE=edge">	<meta content="width=device-width, initial-scale=1, maximum-scale=5" name="viewport">	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">	<title>About Us | Pune Mobile Repairing</title>	<link rel="stylesheet" href="css/animations.css">	<link rel="stylesheet" href="css/bootstrap.min1.css">	<link rel="stylesheet" href="css/font-awesome.min.css">	<link rel="stylesheet" href="css/style.css">	<link rel="stylesheet" href="css/style-faq.css"></head><body id="page-top"><header class="trans_eff">  
    <div class="container">    
        <nav class="navbar rel">      
            <div class="onlySM triBar"> 
                <b></b> <b></b> <b></b> 
            </div>      
            <div class="navbar-header"> 		  
                <a class="navbar-brand trans_eff scroll" href="https://punemobilerepairing.com/"> 
                    <img src="https://punemobilerepairing.com/images/logo.jpg" title="" class="trans_eff logo" alt="">
                </a> 	 
            </div>      
            <div class="mobLoc">	
                <a href="tel:08329441608" class="mycity">
                <img src="https://punemobilerepairing.com/images/callbtn.png" alt="" class="phone"> 8329441608</a>	  
            </div>      
            <div class="navOverlay onlySM animated2"></div>      
            <div class="navbar-custom animated2">        
            <div class="navTitle onlySM">          
            <div class="bar hideNav"> 
                <b class="one"></b> 
                <b class="two"></b> 
            </div>         
            <img src="https://punemobilerepairing.com/images/logo.png" class="trans_eff logo" alt="" style="height:60px;padding:10px 20px 10px;margin-top:10px;">
			<div class="clearfix">
            </div>        
            </div>        
                <ul class="nav navbar-nav navbar-right">          
                    <li class="active"><a href="https://punemobilerepairing.com/">Home</a></li>          
                    <li><a href="https://punemobilerepairing.com/about-us.php">About Us</a></li>          
                    <li><a href="https://punemobilerepairing.com/campaign/">Get A Quote</a></li>		  
                    <li><a href="https://punemobilerepairing.com/contact-us.php">Contact Us</a></li>
                    <li class="noSM">			
                        <a href="tel:08329441608" class="mycity"><img src="himages/callbtn.png" alt="" class="phone">&nbsp; 8329441608</a>
                    </li>        
                </ul>      
            </div>    
        </nav>  
    </div>
</header>

<div class="headerSpacer"></div><section>  <div class="container">    <h2 class="text-reverse"></h2>    <div class="list">      <div class="row">          <div class="col-md-12">            <div class="cta-heading">              <div class="col-sm-12">				  <h2 style="text-align:center;margin-top:18px;margin-bottom:15px;">About Us</h2>				  <p style="text-align:center;">Welcome to Pune Mobile Repairing Doorstep Solution</p>	  					<p style="line-height:30px;text-align:justify;padding:0px 10px;">Pune Mobile Repairing is a revolutionary to simplify electronics devices solution i.e smartphone, laptop, ipad, etc... without making them too hard on your wallet. Find the best solution that needs to get resolve - simple steps to select its brand, model and fault. You will be given our range of solutions to choose from i.e screen replacement, battery replacement, speaker/mic, receiver, charging jack, ect with the best possible quote for your device. Technician will come to your doorstep to work on the device and resolve it. Pune Mobile Repairing offers upto six months warranty on genuine parts. This is the best way & best place, where you will resolve.</p>					<p style="line-height:30px;text-align:justify;padding:0px 10px;">Once the job is completed in front of your eyes at your doorstep by our technician, you can pay using the following methods: Cash, Paytm, UPI (Google Pay, PhonePe). Customers satisfaction is our 1st priority.</p>					<h5 class="h5-xs">Customer Care</h5>					<p>Please help us to make our better solutions & your valuable suggestion and feedback at <b><a href="mailto:punemobilerepairing@gmail.com">punemobilerepairing@gmail.com</a></b> or call us <b><a href="tel:08329441608"> 8329441608</a></b></p>				</div>            </div>          </div>        </div>     </div></section><section class="hdBox">  <div class="container">	      <div class="row" style="margin-bottom:20px;margin-top:10px;">            <div class="col-sm-12">              <blockquote><h2>FAQs</h2></blockquote>              <div class="accordion faq">			  <div id="accordion" role="tablist">					<div class="card panel-wrap">						<div class="card-header" role="tab" id="headingOne">							<h3 class="panel-title">								<span class="square"><i class="fa fa-mobile"></i></span>								<a class="collapsed" data-toggle="collapse" href="#collapseOne" role="button" aria-expanded="false" aria-controls="collapseOne">									What are the solution offered by Pune Mobile Repairing?								</a>							</h3>						</div>						<div id="collapseOne" class="collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion">							<div class="card-body">								<p>Currently, we providing the doorstep solution for all smartphone (i.e iPhone & Android) screens, battery, charging, microphone, speakers, receiver, back panel at your convenience location and time.</p>							</div>						</div>					</div>											<div class="card panel-wrap">						<div class="card-header" role="tab" id="headingTwo">							<h3 class="panel-title">								<span class="square"><i class="fa fa-inr"></i></span>								<a class="collapsed" data-toggle="collapse" href="#collapseTwo" role="button" aria-expanded="false" aria-controls="collapseTwo">									How to find out the chrges/cost?								</a>							</h3>						</div>												<div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordion">							<div class="card-body">								<p>The charges based on the device brand, model & issues/fault etc. Please enter your device details with contact information. Our representative will get in touch with you.</p>							</div>						</div>					</div>											<div class="card panel-wrap">						<div class="card-header" role="tab" id="headingThree">							<h3 class="panel-title">								<span class="square"><i class="fa fa-cog"></i></span>								<a class="collapsed" data-toggle="collapse" href="#collapseThree" role="button" aria-expanded="false" aria-controls="collapseThree">									Do we get any warranty for the spare part?								</a>							</h3>						</div>						<div id="collapseThree" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordion">							<div class="card-body">								<p>Yes, we offer a warranty on genuine parts upto six months for all our screen. You can claim your warranty by writing to us at support@punemobilerepairing.com with device details.</br>								<b>Note : </b>We don’t cover any kind of physical/water damage to the parts. If there is any mishandling, tampering, Reflector Issue of the parts that are observed by our senior technicians it will not be covered under warranty. If you are in need of any further assistance, call our customer service team on 8329441608.</p>							</div>						</div>					</div>											<div class="card panel-wrap">						<div class="card-header" role="tab" id="headingFour">							<h3 class="panel-title">								<span class="square"><i class="fa fa-wrench"></i></span>								<a class="collapsed" data-toggle="collapse" href="#collapseFour" role="button" aria-expanded="false" aria-controls="collapseFour">									How can we fix your cracked screen?								</a>							</h3>						</div>												<div id="collapseFour" class="collapse" role="tabpanel" aria-labelledby="headingFour" data-parent="#accordion">							<div class="card-body">								<p>Our technician will visit at your convenience location with in a time slot to replace your cracked screen in front of your eyes.</p>							</div>						</div>					</div>											<div class="card panel-wrap">						<div class="card-header" role="tab" id="headingFive">							<h3 class="panel-title">								<span class="square"><i class="fa fa-inr"></i></span>								<a class="collapsed" data-toggle="collapse" href="#collapseFive" role="button" aria-expanded="false" aria-controls="collapseFive">									What is the payment method?								</a>							</h3>						</div>						<div id="collapseFive" class="collapse" role="tabpanel" aria-labelledby="headingFive" data-parent="#accordion">							<div class="card-body">								<p>Once the job is completed by our technician, you can pay using the following methods: Cash, Paytm, UPI (Google Pay, PhonePe).</p>							</div>						</div>					</div>															</div>                              </div>            </div>          </div>		<div class="text-center">		  <a href="https://punemobilerepairing.com/campaign/" class="btn customButton">Book Now</a>		</div>  </div></section><section class="whyUs">  <div class="container">    <h2 class="text-reverse"></h2>    <div class="list">      <div class="row">          <div class="col-lg-8 cta-text">            <div class="cta-heading">              <div class="col-sm-12">				  <h2 style="margin-top:0px;color:#fff;">We Can Fix Your Device at Your Doorstep</h2>				  <p style="line-height:30px;color:#fff;text-align:justify;">We understand the irreplaceable role your device in your daily life, serving as a gateway to communication, productivity, and entertainment. However, it is not uncommon for these prized devices to encounter challenges that require the skilled intervention of a specialist. If you are residing in Pune and need reliable screen replacement, you'll be pleased to know that there are several options available in your vicinity.</p>				  <p style="line-height:30px;color:#fff;text-align:justify;">Pune Mobile Repairing is a revolutionary to simplify mobile and tablet solution without making them too hard on your wallet. Find the mobile that needs to get solution, select its brand, model and fault. You will be given our range of solutions to choose from i.e screen replacement, battery replacement, speaker/mic, receiver, charging jack, ect with the best possible quote for your mobile.</p>				</div>            </div>          </div>          <div class="col-lg-4 pl0">            <div class="form-block">              <div class="form-header">                <h4><span>Get A Quote Now</span></h4>              </div>			  			  <form method="post" action="get-info.php" id="fform">																<select name="brand" id="brand" class="form-control" onchange="return select_brand();" required>					<option value="">Select Brand*</option>										<option value="Apple">Apple</option>										<option value="Motorola">Motorola</option>										<option value="One Plus">One Plus</option>										<option value="Oppo">Oppo</option>										<option value="Samsung">Samsung</option>										<option value="Vivo">Vivo</option>										<option value="Xiaomi">Xiaomi</option>									</select>						<select name="model" id="model" class="form-control" onchange="return select_model();" required>					<option value="">Select Model* </option>        				</select>  				<select name="fault" id="fault" class="form-control" required>					<option value="">Select Issue* </option>        				</select>				<input type="submit" class="btn btn-primary" value="Submit" style="width:100%;margin-top:5px;margin-bottom:10px;height:45px;">			  </form>			             </div>          </div>        </div>  </div></section><footer class="footer">  
    <div class="container">    
        <div class="sitemap">      
            <div class="row">        
                <div class="col-xs-12 col-sm-4">          
                    <h4>CONTACT INFO</h4>          
                    <div class="links" role="menu"> 		     
                        <a role="menuitem">Pune Mobile Repairing </a> 			 
                        <a role="menuitem">Shop No.36, Bhaironath Mini Market</a> 		     
                        <a role="menuitem">Pune Solapur Road, Fatimanagar 411013</a> 		  
                    </div>        
                </div>		
                <div class="col-xs-12 col-sm-4">          
                    <h4>QUICK LINKS</h4>          
                    <div class="links" role="menu"> 		     
                        <a href="https://punemobilerepairing.com/" role="menuitem">Home</a> 			 
                        <a href="https://punemobilerepairing.com/about-us.php" role="menuitem">About Us</a> 
						<a href="https://punemobilerepairing.com/campaign/" role="menuitem">Book Now</a> 						
                        <a href="https://punemobilerepairing.com/contact-us.php" role="menuitem">Contact Us</a> 		  
                    </div>        
                </div>        
                <div class="col-xs-12 col-sm-4">          
                    <h4>MORE INFO</h4>          
                    <div class="links" role="menu"> 		
                        <a href="https://punemobilerepairing.com/terms-condition.php" role="menuitem">Terms and Conditions</a>			
                        <a href="https://punemobilerepairing.com/privacy-policy.php" role="menuitem">Privacy Policy</a> 			
                        <a href="https://punemobilerepairing.com/delivery-shipping.php" role="menuitem">Shipping and Delivery</a>
						<a href="https://punemobilerepairing.com/cancellation-and-refund.php" role="menuitem">Cancellation and Refund</a>
                    </div>       
                </div>      
            </div>   
        </div>    
        <div class="fRight">     
            <div class="brand">
                <h4 style="font-size:1.2em;font-weight:600;margin-bottom:15px;">Help & Support</h4></div>	 
                <div class="">        
                    <p>Call : <strong>8329441608</strong></p>	
                    <p>Website : <strong>www.punemobilerepairing.com</strong></p>        
                    <p>Email : <strong>punemobilerepairing@gmail.com</strong></p> 
					<p>Pay : <strong><a href="https://rzp.io/rzp/F1bjTdj" target="_blank">Oneline Payment</a></strong></p> 				
                </div>    
            </div>    
            <div class="clearfix">
        </div>    
        <div class="fText"></div>  
    </div>  
    <div class="copyrightText">    
        <div class="container text-uppercase">Copyright &copy; 2025 <strong>Pune Mobile Repairing</strong> | All Rights Reserved. 
        </div>  
    </div>
</footer>
<p id="back-top" style="display:none;"><a href="#top" class="btn btn-default trans_eff"><i class="fa fa-angle-up"></i></a></p><div class="mobile-footer mob-view">
    <a href="tel:08329441608"><img src="https://punemobilerepairing.com/images/call.png" alt="" style="width:22px;">
     <p>Call Us </p>
    </a>
    <a href="https://punemobilerepairing.com/campaign/"><img src="https://punemobilerepairing.com/images/price.png" alt="" style="width:22px;">
     <p>View Price</p>
    </a>
	<a href="https://punemobilerepairing.com/campaign/"><img src="https://punemobilerepairing.com/images/booknow.png" alt="" style="width:22px;">
     <p>Quote Now</p>
    </a>
    <a href="https://api.whatsapp.com/send?phone=918329441608" target="_blank"><img src="https://punemobilerepairing.com/images/whatsapp.png" alt="" style="width:22px;">
      <p>Whats App</p>
    </a>
</div>
<div class="mob-view">
	<a href="tel:08329441608" class="circleinst"><img src="https://punemobilerepairing.com/images/callicon.png"></a>
	<a href="https://api.whatsapp.com/send?phone=918329441608" class="circlewhts" target="_blank"><img src="https://punemobilerepairing.com/images/whatsapp.png"></a>
</div><link href="https://punemobilerepairing.com/css/style-popup.css" rel="stylesheet">
<div class="modal fade" id="enqform">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content"> 
      <div class="modal-header">
          <img src="https://punemobilerepairing.com/images/logo.png" alt="" class="img-fluid" style="width:125px;margin-left:15px;">
		  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			<span class="sr-only">x</span>
		  </button>
		  <h4 class="form-title" style="text-align:center;margin-top:18px;font-weight:900;">Book Now & Get Resolve in 30 Minutes</h4>	
      </div>
      <div class="modal-body">
        <div class="formCon" id="hero-request-form" style="padding:0px 12px 5px">	
		  <form action='https://punemobilerepairing.com/get-info.php' method="post" id="bookingform">		
			<select name="brand" id="brandnew" class="form-control" onchange="return select_brandnew();" required>
				<option value="" selected="selected">Select Brand*</option>
								<option value="Apple">Apple</option>
								<option value="Motorola">Motorola</option>
								<option value="One Plus">One Plus</option>
								<option value="Oppo">Oppo</option>
								<option value="Samsung">Samsung</option>
								<option value="Vivo">Vivo</option>
								<option value="Xiaomi">Xiaomi</option>
				 
			</select>		  
			<select name="model" id="modelnew" class="form-control" onchange="return select_modelnew();" required>
				<option value="" selected="selected">Select Model*</option>  
			</select>  
			<select name="fault" id="faultnew" class="form-control" required>
				<option value="" selected="selected">Select Fault*</option>        
			</select> 
			<input type="submit" class="btn btn-primary" value="Submit" style="width:100%;margin-top:5px;margin-bottom:10px;height:45px;">
		</form>
        </div>
		
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="iwatch">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content"> 
      <div class="modal-header">
          <img src="https://punemobilerepairing.com/images/logo.png" alt="" class="img-fluid" style="width:125px;margin-left:15px;">
		  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			<span class="sr-only">x</span>
		  </button>
		  <h4 class="form-title" style="text-align:center;margin-top:18px;font-weight:900;">Book Now & Get Resolve in 30 Minutes</h4>	
      </div>
      <div class="modal-body">
        <div class="formCon" id="hero-request-form" style="padding:0px 12px 5px">	
		  <form class="login-form" action='https://punemobilerepairing.com/get-info.php' method="post" id="iwkform">		
			<select name="brand" class="form-control" required>
				<option value="" selected="selected">Select Brand*</option>
				<option value="Apple">Apple</option>
			</select>		  
			<select name="model" class="form-control" required>
				<option value="" selected="selected">Select Model*</option>   
				<option value="Series 1 38MM">Series 1 38MM</option>
				<option value="Series 1 42MM">Series 1 42MM</option>
				<option value="Series 2 38MM">Series 2 38MM</option>
				<option value="Series 2 42MM">Series 2 42MM</option>
				<option value="Series 3 38MM">Series 3 38MM</option>
				<option value="Series 3 42MM">Series 3 42MM</option>
				<option value="Series 4 40MM">Series 4 40MM</option>
				<option value="Series 4 44MM">Series 4 44MM</option>
				<option value="Series 5 40MM">Series 5 40MM</option>
				<option value="Series 5 44MM">Series 5 44MM</option>
				<option value="Series 6 40MM">Series 6 40MM</option>
				<option value="Series 6 44MM">Series 6 44MM</option>
				<option value="Series SE 40MM">Series SE 40MM</option>
				<option value="Series SE 44MM">Series SE 44MM</option> 
				<option value="Series 7 41MM">Series 7 41MM</option>
				<option value="Series 7 45MM">Series 7 45MM</option>
				<option value="Series 8 41MM">Series 8 41MM</option>
				<option value="Series 8 45MM">Series 8 45MM</option>				
			</select>  
			<select name="fault" class="form-control" required>
				<option value="" selected="selected">Select Fault*</option>     
				<option value="Battery">Battery</option>
			    <option value="Back Glass Broken">Back Glass Broken</option>
			    <option value="Glass Broken">Glass Broken</option>
			    <option value="Screen/Display">Screen/Display</option>
			    <option value="Other Issue">Other Issue</option>
			</select> 
			<input type="submit" class="btn btn-primary" value="Submit" style="width:100%;margin-top:5px;margin-bottom:10px;height:45px;">
		</form>
        </div>
		
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="ipad">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content"> 
      <div class="modal-header">
          <img src="https://punemobilerepairing.com/images/logo.png" alt="" class="img-fluid" style="width:125px;margin-left:15px;">
		  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			<span class="sr-only">x</span>
		  </button>
		  <h4 class="form-title" style="text-align:center;margin-top:18px;font-weight:900;">Book Now & Get Resolve in 30 Minutes</h4>	
      </div>
      <div class="modal-body">
        <div class="formCon" id="hero-request-form" style="padding:0px 12px 5px">	
		  <form class="login-form" action='https://punemobilerepairing.com/get-info.php' method="post" id="ipbkform">		
			<select name="brand" id="brandanrd" class="form-control" required>
				<option value="" selected="selected">Select Brand*</option>
				<option value="iPad">Apple iPad</option>
				<option value="Samsung">Samsung</option>
				<option value="Lenovo">Lenovo</option>
				<option value="Other">Other</option>
			</select>
			<input type="text" name="model" placeholder="Enter Model*" class="form-control" required="required" autocomplete="off" maxlength="50">
			<select name="fault" class="form-control" required>
				<option value="" selected="selected">Select Fault*</option>     
				<option value="Back Panel">Back Panel</option>
				<option value="Battery">Battery</option>
				<option value="Camera">Camera</option>
				<option value="Charging">Charging</option>
				<option value="Dead Condition">Dead Condition</option>
				<option value="Headphone">Headphone</option>
				<option value="Home Button">Home Button</option>
				<option value="Other Issue">Other Issue</option>
				<option value="Power Button">Power Button</option>
				<option value="Screen Broken">Screen Broken</option>
				<option value="Speaker/Mic">Speaker/Mic</option>
				<option value="Volum Button">Volum Button</option>   
			</select> 
			<input type="submit" class="btn btn-primary" value="Submit" style="width:100%;margin-top:5px;margin-bottom:10px;height:45px;">
		</form>
        </div>		
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="contact">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content"> 
      <div class="modal-header">
          <img src="https://punemobilerepairing.com/images/logo.png" alt="" class="img-fluid" style="width:125px;margin-left:15px;">
		  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			<span class="sr-only">x</span>
		  </button>
		  <h4 class="form-title" style="text-align:center;margin-top:18px;font-weight:900;">Please don’t hesitate to contact us</h4>	
      </div>
      <div class="modal-body">
        <div class="formCon" id="hero-request-form" style="padding:0px 12px 5px">	
		  <form class="login-form" action='https://punemobilerepairing.com/submitcontact.php' method="post" id="contactform">		
			<input type="hidden" name="ip" value="157.32.211.225">
			<input type="text" name="name" placeholder="Enter Name*" class="form-control" required autocomplete="off" maxlength="50">
			<input type="email" name="email" placeholder="Enter Email*" class="form-control" required autocomplete="off" maxlength="50">
			<input type="tel" name="mobile" placeholder="Enter Mobile No*" class="form-control" required autocomplete="off" maxlength="10" minlength="10">
			<textarea name="comments" id="comments" rows="4" class="form-control" required placeholder="Your Message*"></textarea>
			<input type="submit" class="btn btn-primary" value="Submit" style="width:100%;margin-top:5px;margin-bottom:10px;height:45px;">
		</form>
        </div>
		
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="termsofuse">
  <div class="modal-dialog modal-dialog-centered tofuse">
    <div class="modal-content"> 
      <div class="modal-header">
          <img src="https://punemobilerepairing.com/images/logo.png" alt="" class="img-fluid" style="width:125px;margin-left:15px;">
		  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			<span class="sr-only">x</span>
		  </button>
		  <h4 class="form-title" style="text-align:center;margin-top:18px;font-weight:900;">Terms Conditions</h4>	
		  <p style="text-align:center;">Please read carefully the terms & conditions. We will try to our best to complete the job.</p>
      </div>
      <div class="modal-body">
		 <div>  
			<li style="line-height:25px;text-align:justify;">All the estimate cost are approximate and subject to change (may or may not) on completion of job.</li>
			<li style="line-height:25px;text-align:justify;">All articles(mobile/tablet) taken for the solution shall be subject to customer risk.</li>
			<li style="line-height:25px;text-align:justify;">Physical/Liquid damage device may or may not be returned in same condition after opening the device.</li>
			<li style="line-height:25px;text-align:justify;">Any parts replaced by Pune Mobile Repairing during solution and face any quality issue, same will be replace within upto 180 days from the date of repair/services.</li>
			<li style="line-height:25px;text-align:justify;">Replaced parts will be covered under the warranty peroid of 180 days from the date of repair.</li>
			<li style="line-height:25px;text-align:justify;">Please ensure your data is backup before solution of your device from our engineer/technician.</li>
			<li style="line-height:25px;text-align:justify;">We do not offer data recovery solution only providing solution.</li>
			<li style="line-height:25px;text-align:justify;">Visit charges of Rs.499/- has to be paid in case of revisit, Warranty will covered in only spare parts/replaced parts.</li>				
			<br/>              
		</div>
	  </div>
		
    </div>
  </div>
</div>

<div class="modal fade" id="aboutussection">
  <div class="modal-dialog modal-dialog-centered tofuse">
    <div class="modal-content"> 
      <div class="modal-header">
          <img src="https://punemobilerepairing.com/images/logo.png" alt="" class="img-fluid" style="width:125px;margin-left:15px;">
		  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			<span class="sr-only">x</span>
		  </button>
		  <h4 class="form-title" style="text-align:center;margin-top:20px;margin-bottom:20px;font-weight:900;color:#000;font-size:25px">About Us</h4>
		  <p style="text-align:center;">Welcome to Pune Mobile Repairing Doorstep Solution</p>
      </div>
      <div class="modal-body">
		 <div>  
			<p style="line-height:30px;text-align:justify;padding:0px 10px;">Pune Mobile Repairing is a revolutionary to simplify electronics devices solution i.e smartphone, laptop, ipad, etc... without making them too hard on your wallet. Find the best solution that needs to get resolve - simple steps to select its brand, model and fault. You will be given our range of solutions to choose from i.e screen replacement, battery replacement, speaker/mic, receiver, charging jack, ect with the best possible quote for your device. Technician will come to your doorstep to work on the device and resolve it. Pune Mobile Repairing offers upto six months warranty on genuine parts. This is the best way & best place, where you will resolve.</p>
			<p style="line-height:30px;text-align:justify;padding:0px 10px;">Once the job is completed in front of your eyes at your doorstep by our technician, you can pay using the following methods: Cash, Paytm, UPI (Google Pay, PhonePe). Customers satisfaction is our 1st priority.</p>
			<p style="line-height:30px;text-align:justify;padding:0px 10px;">Please help us to make our better solutions & your valuable suggestion and feedback at 
				<a href="mailto:punemobilerepairing@gmail.com">punemobilerepairing@gmail.com</a> or call us <a href="tel:08329441608"> 8329441608</a>
			</p>	
			<br/>                   
		</div>
	  </div>
		
    </div>
  </div>
</div>

<div class="modal fade" id="contactus">
  <div class="modal-dialog modal-dialog-centered tcontus">
    <div class="modal-content"> 
      <div class="modal-header">
          <img src="https://punemobilerepairing.com/images/logo.png" alt="" class="img-fluid" style="width:125px;margin-left:15px;">
		  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			<span class="sr-only">x</span>
		  </button>
		  <h4 class="form-title" style="text-align:center;margin-top:18px;font-weight:900;color:#000;">CONTACT INFO</h4>	
      </div>
      <div class="modal-body">
		 <div class="row" style="padding:0px 20px 25px;">
			<div class="col-xs-12 col-sm-12">
			  <h4><b>Contact Us</b></h4>
			  <div class="links" role="menu"> 
				 <a role="menuitem"><strong>Shop No.36, Bhaironath Mini Market, Pune Solapur Road, Fatimanagar, Pune Maharashtra 411013 </strong></a> <br/><br/>
				 <p>Contact No. : <strong>+91-8329441608</strong></p>
				 <p>Website : <strong>www.punemobilerepairing.com</strong></p>
				 <p>Email : <strong>punemobilerepairing@gmail.com</strong></p>
			  </div>
			</div>
		</div>
		 
	  </div>
		
    </div>
  </div>
</div>

<script type="text/javascript">	
function select_brand(){
	var brand = $('#brand').val();
	if(brand !=""){
		brand = "brand="+brand;
		$.ajax({
			url:'https://punemobilerepairing.com/fetch.php',
			type:'get',
			data:brand
			}).done(function (data){
				$('#model').html(data);
			})
		}
	}
function select_model(){
	var model = $('#model').val();
	if(model !=""){
		model = "model="+model;
		$.ajax({
			url:'https://punemobilerepairing.com/fetch-model.php',
			type:'get',
			data:model
			}).done(function (data){
				$('#fault').html(data);
			})
		}
	}
function select_brandnew(){
	var brandnew = $('#brandnew').val();
	if(brandnew !=""){
		brandnew = "brandnew="+brandnew;
		$.ajax({
			url:'https://punemobilerepairing.com/fetchnew.php',
			type:'get',
			data:brandnew
			}).done(function (data){
				$('#modelnew').html(data);
			})
		}
	}
function select_modelnew(){
	var modelnew = $('#modelnew').val();
	if(modelnew !=""){
		modelnew = "modelnew="+modelnew;
		$.ajax({
			url:'https://punemobilerepairing.com/fetch-modelnew.php',
			type:'get',
			data:modelnew
			}).done(function (data){
				$('#faultnew').html(data);
			})
		}
	}	
function select_brandanrd(){
	var brandanrd = $('#brandanrd').val();
	if(brandanrd !=""){
		brandanrd = "brandanrd="+brandanrd;
		$.ajax({
			url:'https://punemobilerepairing.com/fetchanrd.php',
			type:'get',
			data:brandanrd
			}).done(function (data){
				$('#modelanrd').html(data);
			})
		}
	}
function select_modelanrd(){
	var modelanrd = $('#modelanrd').val();
	if(modelanrd !=""){
		modelanrd = "modelanrd="+modelanrd;
		$.ajax({
			url:'https://punemobilerepairing.com/fetch-modelanrd.php',
			type:'get',
			data:modelanrd
			}).done(function (data){
				$('#faultanrd').html(data);
			})
		}
	}		
function checkIt(evt) {
	evt = (evt) ? evt : window.event
	var charCode = (evt.which) ? evt.which : evt.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		status = "This field accepts numbers only."
		return false
	}
	status = ""
	return true
}
</script>	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script><script src="scripts/function.js"></script><script src="js1/jquery-3.3.1.min.js"></script><script src="js1/bootstrap.min.js"></script>	<script src="js1/jquery.flexslider.js"></script><script type="text/javascript">	$().ready(function() { $("#fform").validate({	rules: {			brand: "required",		model: "required",		fault: "required",		color: "required",		},	messages: {		brand: "Select Brand",		model: "Select Model",		fault: "Select Fault",		color: "Select Screen Color",	},	submitHandler: function(form){         $('form input[type=submit]').attr('disabled', 'disabled');         form.submit();       }  });		});$().ready(function() { $("#bookingform").validate({	rules: {			brand: "required",		model: "required",		fault: "required",		color: "required",		},	messages: {		brand: "Select Brand",		model: "Select Model",		fault: "Select Fault",		color: "Select Screen Color",	},	submitHandler: function(form){         $('form input[type=submit]').attr('disabled', 'disabled');         form.submit();       }  });		});$().ready(function() { $("#ibkform").validate({	rules: {			brand: "required",		model: "required",		fault: "required",		color: "required",		},	messages: {		brand: "Select Brand",		model: "Select Model",		fault: "Select Fault",		color: "Select Screen Color",	},	submitHandler: function(form){         $('form input[type=submit]').attr('disabled', 'disabled');         form.submit();       }  });		});$().ready(function() { $("#abkform").validate({	rules: {			brand: "required",		model: "required",		fault: "required",		color: "required",		},	messages: {		brand: "Select Brand",		model: "Select Model",		fault: "Select Fault",		color: "Select Screen Color",	},	submitHandler: function(form){         $('form input[type=submit]').attr('disabled', 'disabled');         form.submit();       }  });		});$().ready(function() { $("#ipbkform").validate({	rules: {			brand: "required",		model: "required",		fault: "required",		color: "required",		},	messages: {		brand: "Select Brand",		model: "Select Model",		fault: "Select Fault",		color: "Select Screen Color",	},	submitHandler: function(form){         $('form input[type=submit]').attr('disabled', 'disabled');         form.submit();       }  });		});$().ready(function() { $("#iwbkform").validate({	rules: {			brand: "required",		model: "required",		fault: "required",		color: "required",		},	messages: {		brand: "Select Brand",		model: "Select Model",		fault: "Select Fault",		color: "Select Screen Color",	},	submitHandler: function(form){         $('form input[type=submit]').attr('disabled', 'disabled');         form.submit();       }  });		});$().ready(function() { $("#contactform").validate({	rules: {			name: "required",		email: "required",		mobile: "required",		comments: "required",	},	messages: {		name: "Enter Name",		email: "Enter email",		mobile: "Enter Valid Mobile No.",		comments: "Enter Message/Comment",	},	submitHandler: function(form){         $('form input[type=submit]').attr('disabled', 'disabled');         form.submit();       }  });		});</script><script type="text/javascript">$(document).ready(function () {	$(document)[0].oncontextmenu = function () {		return false;	}	$(document).mousedown(function (e) {		if (e.button === 2) {			return false;		} else {			return true;		}	});	document.onkeydown = function (e) {		if (e.ctrlKey &&				(e.keyCode === 67 ||						e.keyCode === 86 ||						e.keyCode === 85 ||						e.keyCode === 117 ||						e.keyCode === 83 ||						e.keyCode === 74						) ) {			return false;		} else {			return true;		}	};});</script></body></html>